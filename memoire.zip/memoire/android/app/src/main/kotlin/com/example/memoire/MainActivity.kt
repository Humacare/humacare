package com.example.memoire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
