

const String tLogin = "Login";
const String tSignup = "Signup";
const String tEmail = "E-mail";
const String tPassword = "Password";
const String tForgotPassword = "Forgot password?";
const String tSignInGoogle = "Sign-In with Google";


const String tAppName = ".HumaCare";
const String tAppTagLine = "Your Doctor Appointment Easy";

const String tWelcomeTitle = "welcome to Humacare ";
const String tWelcomeSubTitle = "We care About Your Health";

const String tLoginTitle = "Welcome back";
const String tLoginSubTitle = "Care About Your Health";
const String tRememberMe = "Remember me?";
const String tDontHaveAcc = "Don't Have An Account?";

const String tSignupTitle = "Get On Board";
const String tSignupSubTitle = "Create Your Profile Now";
const String tAlreadyHaveAcc = "Already have an account";

const String tFullName = "FullName";
