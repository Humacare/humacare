
const String tSplashTopIcon = "assets/images/splash_screen_imageq/images.png";
const String tSplashImage = "assets/images/welcome_images/welcm2.png";

const String tWelcomeScreenImage = "assets/images/welcome_images/welcm.png";


const String tGoogleLogo = "assets/logo/google.png";