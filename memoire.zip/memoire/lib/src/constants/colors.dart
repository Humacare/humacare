import 'package:flutter/material.dart';
import 'dart:ui';

const tPrimaryColor = Colors.blueAccent;
const tSecondaryColor = Colors.greenAccent;
const tAccentColor = Colors.black;
const tWhiteColor = Colors.white;
const tDarkColor = Color(0xff000000);
const tCardBgColor = Color(0xFFF7F6F1);
/*const tPrimaryColor = Color(value);
const tPrimaryColor = Color(value);
const tPrimaryColor = Color(value); **/
